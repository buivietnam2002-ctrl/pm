import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../models/cad_models.dart';

class CadController extends ChangeNotifier {
  String projectName = 'Khao sat mat bang 2D';
  String surveyorName = 'Ky thuat vien';

  final List<CadLine> _lines = [];
  final List<List<CadLine>> _undoStack = [];
  final List<List<CadLine>> _redoStack = [];

  ToolMode toolMode = ToolMode.drawLine;
  CadLayer activeLayer = CadLayer.walls;

  bool orthoEnabled = true;
  bool snapEnabled = true;
  double gridSizeMm = 100.0;

  // Viewport transform: screen = world * scale + panOffset
  double scale = 0.12; // 1000mm = 120px mặc định
  Offset panOffset = const Offset(120, 180);

  String? selectedLineId;

  // Trạng thái đang vẽ tương tác
  CadPoint? activeStartPoint;
  CadPoint? activePreviewEndPoint;
  SnapResult? currentSnap;

  List<CadLine> get lines => List.unmodifiable(_lines);
  bool get canUndo => _undoStack.isNotEmpty;
  bool get canRedo => _redoStack.isNotEmpty;

  CadLine? get selectedLine {
    if (selectedLineId == null) return null;
    for (final line in _lines) {
      if (line.id == selectedLineId) return line;
    }
    return null;
  }

  void setProjectInfo({String? project, String? surveyor}) {
    if (project != null && project.trim().isNotEmpty) {
      projectName = project.trim();
    }
    if (surveyor != null && surveyor.trim().isNotEmpty) {
      surveyorName = surveyor.trim();
    }
    notifyListeners();
  }

  void setToolMode(ToolMode mode) {
    toolMode = mode;
    if (mode != ToolMode.drawLine) {
      activeStartPoint = null;
      activePreviewEndPoint = null;
      currentSnap = null;
    }
    notifyListeners();
  }

  void setActiveLayer(CadLayer layer) {
    activeLayer = layer;
    notifyListeners();
  }

  void toggleOrtho() {
    orthoEnabled = !orthoEnabled;
    notifyListeners();
  }

  void toggleSnap() {
    snapEnabled = !snapEnabled;
    notifyListeners();
  }

  void setGridSize(double mm) {
    gridSizeMm = mm;
    notifyListeners();
  }

  Offset worldToScreen(CadPoint p) {
    return Offset(p.x * scale + panOffset.dx, p.y * scale + panOffset.dy);
  }

  CadPoint screenToWorld(Offset screenPos) {
    return CadPoint(
      (screenPos.dx - panOffset.dx) / scale,
      (screenPos.dy - panOffset.dy) / scale,
    );
  }

  void panBy(Offset delta) {
    panOffset += delta;
    notifyListeners();
  }

  void zoomAt(double zoomFactor, Offset focalScreenPoint) {
    final newScale = (scale * zoomFactor).clamp(0.02, 2.5);
    final worldBefore = screenToWorld(focalScreenPoint);
    scale = newScale;
    final screenAfter = worldToScreen(worldBefore);
    panOffset += focalScreenPoint - screenAfter;
    notifyListeners();
  }

  void zoomToFit(Size canvasSize) {
    if (_lines.isEmpty || canvasSize.isEmpty) {
      scale = 0.12;
      panOffset = Offset(canvasSize.width * 0.15, canvasSize.height * 0.2);
      notifyListeners();
      return;
    }

    double minX = double.infinity;
    double minY = double.infinity;
    double maxX = double.negativeInfinity;
    double maxY = double.negativeInfinity;

    for (final l in _lines) {
      minX = math.min(minX, math.min(l.start.x, l.end.x));
      maxX = math.max(maxX, math.max(l.start.x, l.end.x));
      minY = math.min(minY, math.min(l.start.y, l.end.y));
      maxY = math.max(maxY, math.max(l.start.y, l.end.y));
    }

    final widthMm = math.max(maxX - minX, 200.0);
    final heightMm = math.max(maxY - minY, 200.0);
    final padding = 80.0;

    final scaleX = (canvasSize.width - padding * 2) / widthMm;
    final scaleY = (canvasSize.height - padding * 2) / heightMm;
    scale = math.min(scaleX, scaleY).clamp(0.02, 2.0);

    final centerWorldX = (minX + maxX) / 2.0;
    final centerWorldY = (minY + maxY) / 2.0;

    panOffset = Offset(
      canvasSize.width / 2.0 - centerWorldX * scale,
      canvasSize.height / 2.0 - centerWorldY * scale,
    );
    notifyListeners();
  }

  /// Bắt điểm thông minh (Endpoint -> Midpoint -> Grid) trong bán kính màn hình ~22px.
  SnapResult findSnap(CadPoint rawWorld, {CadPoint? orthoAnchor}) {
    CadPoint target = rawWorld;
    SnapType type = SnapType.none;

    if (snapEnabled) {
      final thresholdMm = 24.0 / scale;
      double bestDist = thresholdMm;

      // 1. Ưu tiên Endpoint
      for (final line in _lines) {
        for (final pt in [line.start, line.end]) {
          final d = pt.distanceTo(rawWorld);
          if (d < bestDist) {
            bestDist = d;
            target = pt;
            type = SnapType.endpoint;
          }
        }
      }

      // 2. Midpoint nếu chưa bắt được Endpoint
      if (type == SnapType.none) {
        for (final line in _lines) {
          final mid = line.midpoint;
          final d = mid.distanceTo(rawWorld);
          if (d < bestDist) {
            bestDist = d;
            target = mid;
            type = SnapType.midpoint;
          }
        }
      }

      // 3. Snap theo lưới (Grid)
      if (type == SnapType.none && gridSizeMm > 0) {
        final gx = (rawWorld.x / gridSizeMm).round() * gridSizeMm;
        final gy = (rawWorld.y / gridSizeMm).round() * gridSizeMm;
        target = CadPoint(gx, gy);
        type = SnapType.grid;
      }
    }

    // 4. Áp dụng khóa vuông góc (Ortho Lock) nếu có điểm gốc
    if (orthoEnabled && orthoAnchor != null) {
      final dx = target.x - orthoAnchor.x;
      final dy = target.y - orthoAnchor.y;
      if (dx.abs() >= dy.abs()) {
        target = CadPoint(target.x, orthoAnchor.y);
      } else {
        target = CadPoint(orthoAnchor.x, target.y);
      }
    }

    return SnapResult(target, type);
  }

  void startDrawingAt(Offset screenPos) {
    final raw = screenToWorld(screenPos);
    final snapped = findSnap(raw);
    activeStartPoint = snapped.point;
    activePreviewEndPoint = snapped.point;
    currentSnap = snapped;
    selectedLineId = null;
    notifyListeners();
  }

  void updateDrawingTo(Offset screenPos) {
    if (activeStartPoint == null) return;
    final raw = screenToWorld(screenPos);
    final snapped = findSnap(raw, orthoAnchor: activeStartPoint);
    activePreviewEndPoint = snapped.point;
    currentSnap = snapped;
    notifyListeners();
  }

  /// Kết thúc kéo tay: trả về chiều dài và góc nháp để mở hộp thoại nhập số đo mm chính xác.
  ({CadPoint start, CadPoint end, double lengthMm, double angleDeg})?
      finishDrawingDraft() {
    if (activeStartPoint == null || activePreviewEndPoint == null) return null;
    final start = activeStartPoint!;
    final end = activePreviewEndPoint!;
    final dist = start.distanceTo(end);
    final angle = math.atan2(end.y - start.y, end.x - start.x) * 180.0 / math.pi;

    if (dist < 10.0 / scale) {
      // Kéo quá ngắn -> hủy nháp
      cancelDrawing();
      return null;
    }

    return (start: start, end: end, lengthMm: dist, angleDeg: angle);
  }

  void cancelDrawing() {
    activeStartPoint = null;
    activePreviewEndPoint = null;
    currentSnap = null;
    notifyListeners();
  }

  /// Xác nhận thêm đoạn thẳng với chiều dài (mm) và góc (độ) chính xác.
  void commitLineExact({
    required CadPoint start,
    required double lengthMm,
    required double angleDeg,
    CadLayer? layer,
    String? note,
  }) {
    if (lengthMm <= 0) return;
    _pushUndo();
    final rad = angleDeg * math.pi / 180.0;
    final end = CadPoint(
      start.x + lengthMm * math.cos(rad),
      start.y + lengthMm * math.sin(rad),
    );
    final newLine = CadLine(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      start: start,
      end: end,
      layer: layer ?? activeLayer,
      note: note,
    );
    _lines.add(newLine);
    selectedLineId = newLine.id;
    activeStartPoint = null;
    activePreviewEndPoint = null;
    currentSnap = null;
    notifyListeners();
  }

  /// Chọn đoạn thẳng tại vị trí chạm màn hình.
  CadLine? selectAt(Offset screenPos) {
    final worldPos = screenToWorld(screenPos);
    final hitThresholdMm = 22.0 / scale;
    CadLine? closest;
    double bestDist = hitThresholdMm;

    for (final line in _lines) {
      final d = line.distanceToPoint(worldPos);
      if (d < bestDist) {
        bestDist = d;
        closest = line;
      }
    }

    selectedLineId = closest?.id;
    notifyListeners();
    return closest;
  }

  /// Chỉnh sửa chiều dài (mm), góc, layer hoặc ghi chú của đoạn thẳng đang chọn.
  void updateLine({
    required String lineId,
    required double newLengthMm,
    double? newAngleDeg,
    CadLayer? newLayer,
    String? newNote,
    bool anchorStart = true,
  }) {
    final index = _lines.indexWhere((l) => l.id == lineId);
    if (index == -1 || newLengthMm <= 0) return;

    _pushUndo();
    var line = _lines[index];

    if (newAngleDeg != null) {
      final rad = newAngleDeg * math.pi / 180.0;
      if (anchorStart) {
        line = line.copyWith(
          end: CadPoint(
            line.start.x + newLengthMm * math.cos(rad),
            line.start.y + newLengthMm * math.sin(rad),
          ),
        );
      } else {
        line = line.copyWith(
          start: CadPoint(
            line.end.x - newLengthMm * math.cos(rad),
            line.end.y - newLengthMm * math.sin(rad),
          ),
        );
      }
    } else {
      line = line.withExactLength(newLengthMm, anchorStart: anchorStart);
    }

    _lines[index] = line.copyWith(
      layer: newLayer ?? line.layer,
      note: newNote,
    );
    notifyListeners();
  }

  void deleteSelectedLine() {
    if (selectedLineId == null) return;
    _pushUndo();
    _lines.removeWhere((l) => l.id == selectedLineId);
    selectedLineId = null;
    notifyListeners();
  }

  void clearAll() {
    if (_lines.isEmpty) return;
    _pushUndo();
    _lines.clear();
    selectedLineId = null;
    notifyListeners();
  }

  void loadSampleKitchenSurvey() {
    _pushUndo();
    _lines.clear();
    // Ví dụ khảo sát mặt bằng bếp chữ L (đơn vị mm)
    _lines.addAll([
      const CadLine(
        id: 's1',
        start: CadPoint(0, 0),
        end: CadPoint(3600, 0),
        layer: CadLayer.walls,
        note: 'Tuong hau bep',
      ),
      const CadLine(
        id: 's2',
        start: CadPoint(3600, 0),
        end: CadPoint(3600, 2400),
        layer: CadLayer.walls,
        note: 'Tuong phai',
      ),
      const CadLine(
        id: 's3',
        start: CadPoint(0, 0),
        end: CadPoint(0, 1800),
        layer: CadLayer.walls,
        note: 'Tuong trai',
      ),
      const CadLine(
        id: 's4',
        start: CadPoint(1100, 0),
        end: CadPoint(2300, 0),
        layer: CadLayer.openings,
        note: 'Cua so',
      ),
      const CadLine(
        id: 's5',
        start: CadPoint(0, 600),
        end: CadPoint(3000, 600),
        layer: CadLayer.furniture,
        note: 'Mep tu duoi',
      ),
      const CadLine(
        id: 's6',
        start: CadPoint(3000, 600),
        end: CadPoint(3000, 2400),
        layer: CadLayer.furniture,
        note: 'Canh L tu duoi',
      ),
    ]);
    selectedLineId = null;
    notifyListeners();
  }

  void _pushUndo() {
    _undoStack.add(List<CadLine>.from(_lines));
    _redoStack.clear();
    if (_undoStack.length > 40) {
      _undoStack.removeAt(0);
    }
  }

  void undo() {
    if (_undoStack.isEmpty) return;
    _redoStack.add(List<CadLine>.from(_lines));
    _lines
      ..clear()
      ..addAll(_undoStack.removeLast());
    selectedLineId = null;
    notifyListeners();
  }

  void redo() {
    if (_redoStack.isEmpty) return;
    _undoStack.add(List<CadLine>.from(_lines));
    _lines
      ..clear()
      ..addAll(_redoStack.removeLast());
    selectedLineId = null;
    notifyListeners();
  }
}
