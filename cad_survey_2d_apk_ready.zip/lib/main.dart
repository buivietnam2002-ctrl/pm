import 'package:flutter/material.dart';
import 'screens/cad_editor_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CadSurveyApp());
}

class CadSurveyApp extends StatelessWidget {
  const CadSurveyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CAD Survey 2D',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF38BDF8),
          secondary: Color(0xFFF59E0B),
          surface: Color(0xFF0F172A),
          onSurface: Color(0xFFF8FAFC),
        ),
        scaffoldBackgroundColor: const Color(0xFF0B1120),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF0F172A),
          foregroundColor: Color(0xFFF8FAFC),
          elevation: 0,
        ),
      ),
      home: const CadEditorScreen(),
    );
  }
}
