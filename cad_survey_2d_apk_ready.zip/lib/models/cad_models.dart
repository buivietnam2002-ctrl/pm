import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Điểm tọa độ 2D trong không gian thực (đơn vị: mm).
class CadPoint {
  final double x;
  final double y;

  const CadPoint(this.x, this.y);

  double distanceTo(CadPoint other) {
    final dx = other.x - x;
    final dy = other.y - y;
    return math.sqrt(dx * dx + dy * dy);
  }

  CadPoint operator +(CadPoint other) => CadPoint(x + other.x, y + other.y);
  CadPoint operator -(CadPoint other) => CadPoint(x - other.x, y - other.y);

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CadPoint &&
          (x - other.x).abs() < 1e-6 &&
          (y - other.y).abs() < 1e-6;

  @override
  int get hashCode => Object.hash(x.toStringAsFixed(3), y.toStringAsFixed(3));
}

/// Các lớp (Layer) tiêu chuẩn cho bản vẽ khảo sát công trình / nội thất.
enum CadLayer {
  walls(
    dxfName: 'WALL',
    label: 'Tường / Kết cấu',
    color: Color(0xFFF8FAFC),
    aciColor: 7, // White/Black in AutoCAD
    strokeWidth: 2.4,
  ),
  furniture(
    dxfName: 'CABINET',
    label: 'Tủ / Nội thất',
    color: Color(0xFF38BDF8),
    aciColor: 4, // Cyan
    strokeWidth: 1.8,
  ),
  openings(
    dxfName: 'OPENING',
    label: 'Cửa đi / Cửa sổ',
    color: Color(0xFFF59E0B),
    aciColor: 2, // Yellow
    strokeWidth: 1.8,
  ),
  annotations(
    dxfName: 'MEP_NOTE',
    label: 'Điện nước / Ghi chú',
    color: Color(0xFF34D399),
    aciColor: 3, // Green
    strokeWidth: 1.5,
  );

  final String dxfName;
  final String label;
  final Color color;
  final int aciColor;
  final double strokeWidth;

  const CadLayer({
    required this.dxfName,
    required this.label,
    required this.color,
    required this.aciColor,
    required this.strokeWidth,
  });
}

/// Đoạn thẳng vector 2D (đơn vị mm).
class CadLine {
  final String id;
  final CadPoint start;
  final CadPoint end;
  final CadLayer layer;
  final String? note;

  const CadLine({
    required this.id,
    required this.start,
    required this.end,
    this.layer = CadLayer.walls,
    this.note,
  });

  double get lengthMm => start.distanceTo(end);

  double get angleRad => math.atan2(end.y - start.y, end.x - start.x);

  /// Góc theo độ trong hệ tọa độ bản vẽ (0° là hướng phải, 90° là hướng xuống trên màn hình).
  double get angleDeg => angleRad * 180.0 / math.pi;

  CadPoint get midpoint =>
      CadPoint((start.x + end.x) / 2.0, (start.y + end.y) / 2.0);

  CadLine copyWith({
    String? id,
    CadPoint? start,
    CadPoint? end,
    CadLayer? layer,
    String? note,
  }) {
    return CadLine(
      id: id ?? this.id,
      start: start ?? this.start,
      end: end ?? this.end,
      layer: layer ?? this.layer,
      note: note ?? this.note,
    );
  }

  /// Trả về đoạn thẳng mới có chiều dài chính xác (mm), giữ nguyên điểm đầu hoặc điểm cuối.
  CadLine withExactLength(double newLengthMm, {bool anchorStart = true}) {
    if (newLengthMm <= 0) return this;
    final currentLen = lengthMm;
    final angle = currentLen > 1e-6 ? angleRad : 0.0;
    if (anchorStart) {
      final newEnd = CadPoint(
        start.x + newLengthMm * math.cos(angle),
        start.y + newLengthMm * math.sin(angle),
      );
      return copyWith(end: newEnd);
    } else {
      final newStart = CadPoint(
        end.x - newLengthMm * math.cos(angle),
        end.y - newLengthMm * math.sin(angle),
      );
      return copyWith(start: newStart);
    }
  }

  /// Tính khoảng cách vuông góc từ một điểm bất kỳ tới đoạn thẳng (dùng cho chọn đối tượng).
  double distanceToPoint(CadPoint p) {
    final dx = end.x - start.x;
    final dy = end.y - start.y;
    final lenSq = dx * dx + dy * dy;
    if (lenSq < 1e-9) return start.distanceTo(p);
    final t = (((p.x - start.x) * dx + (p.y - start.y) * dy) / lenSq)
        .clamp(0.0, 1.0);
    final proj = CadPoint(start.x + t * dx, start.y + t * dy);
    return proj.distanceTo(p);
  }
}

enum ToolMode {
  drawLine,
  selectEdit,
  panZoom,
}

enum SnapType {
  none,
  endpoint,
  midpoint,
  grid,
}

class SnapResult {
  final CadPoint point;
  final SnapType type;

  const SnapResult(this.point, this.type);
}
