import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../controllers/cad_controller.dart';
import '../models/cad_models.dart';
import '../services/dxf_exporter.dart';
import '../services/pdf_exporter.dart';
import '../widgets/cad_canvas.dart';
import '../widgets/dimension_input_dialog.dart';

class CadEditorScreen extends StatefulWidget {
  const CadEditorScreen({super.key});

  @override
  State<CadEditorScreen> createState() => _CadEditorScreenState();
}

class _CadEditorScreenState extends State<CadEditorScreen> {
  final CadController _controller = CadController();
  final GlobalKey _canvasKey = GlobalKey();
  bool _isExporting = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Size _getCanvasSize() {
    final renderBox =
        _canvasKey.currentContext?.findRenderObject() as RenderBox?;
    return renderBox?.size ?? MediaQuery.of(context).size;
  }

  Future<void> _handleLineDraftFinished(
    CadPoint start,
    double draftLengthMm,
    double draftAngleDeg,
  ) async {
    final result = await showDimensionInputDialog(
      context: context,
      initialLengthMm: draftLengthMm,
      initialAngleDeg: draftAngleDeg,
      initialLayer: _controller.activeLayer,
    );

    if (result != null) {
      _controller.commitLineExact(
        start: start,
        lengthMm: result.lengthMm,
        angleDeg: result.angleDeg,
        layer: result.layer,
        note: result.note,
      );
    } else {
      _controller.cancelDrawing();
    }
  }

  Future<void> _handleLineTappedForEdit(CadLine line) async {
    final result = await showDimensionInputDialog(
      context: context,
      initialLengthMm: line.lengthMm,
      initialAngleDeg: line.angleDeg,
      initialLayer: line.layer,
      initialNote: line.note,
      isEditing: true,
    );

    if (result == null) return;
    if (result.deleted) {
      _controller.deleteSelectedLine();
      return;
    }

    _controller.updateLine(
      lineId: line.id,
      newLengthMm: result.lengthMm,
      newAngleDeg: result.angleDeg,
      newLayer: result.layer,
      newNote: result.note,
      anchorStart: result.anchorStart,
    );
  }

  Future<void> _exportDxf() async {
    if (_controller.lines.isEmpty) {
      _showSnack('Bản vẽ chưa có đoạn thẳng nào để xuất DXF.');
      return;
    }
    setState(() => _isExporting = true);
    try {
      final dxfContent = DxfExporter.generateDxf(
        lines: _controller.lines,
        projectName: _controller.projectName,
      );
      final dir = await getTemporaryDirectory();
      final stamp = DateFormat('yyyyMMdd_HHmmss').format(DateTime.now());
      final file = File('${dir.path}/khao_sat_$stamp.dxf');
      await file.writeAsString(dxfContent);

      await Share.shareXFiles(
        [XFile(file.path)],
        subject: 'Ban ve DXF - ${_controller.projectName}',
      );
    } catch (e) {
      _showSnack('Lỗi khi xuất DXF: $e');
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  Future<void> _exportPdf() async {
    if (_controller.lines.isEmpty) {
      _showSnack('Bản vẽ chưa có đoạn thẳng nào để xuất PDF.');
      return;
    }
    setState(() => _isExporting = true);
    try {
      final bytes = await PdfExporter.generatePdf(
        lines: _controller.lines,
        projectName: _controller.projectName,
        surveyorName: _controller.surveyorName,
      );
      final dir = await getTemporaryDirectory();
      final stamp = DateFormat('yyyyMMdd_HHmmss').format(DateTime.now());
      final file = File('${dir.path}/khao_sat_$stamp.pdf');
      await file.writeAsBytes(bytes);

      await Share.shareXFiles(
        [XFile(file.path)],
        subject: 'Ban ve PDF - ${_controller.projectName}',
      );
    } catch (e) {
      _showSnack('Lỗi khi xuất PDF: $e');
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  Future<void> _editProjectInfo() async {
    final projCtrl = TextEditingController(text: _controller.projectName);
    final survCtrl = TextEditingController(text: _controller.surveyorName);

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Thông tin công trình'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: projCtrl,
              decoration: const InputDecoration(labelText: 'Tên công trình'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: survCtrl,
              decoration: const InputDecoration(labelText: 'Người đo đạc'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Hủy'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Lưu'),
          ),
        ],
      ),
    );

    if (ok == true) {
      _controller.setProjectInfo(
        project: projCtrl.text,
        surveyor: survCtrl.text,
      );
    }
    projCtrl.dispose();
    survCtrl.dispose();
  }

  void _showSnack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _controller,
      builder: (context, _) {
        return Scaffold(
          appBar: AppBar(
            title: InkWell(
              onTap: _editProjectInfo,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _controller.projectName,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    '${_controller.lines.length} đoạn • Đơn vị: mm',
                    style: const TextStyle(
                      fontSize: 11,
                      color: Color(0xFF94A3B8),
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.undo),
                tooltip: 'Hoàn tác',
                onPressed: _controller.canUndo ? _controller.undo : null,
              ),
              IconButton(
                icon: const Icon(Icons.redo),
                tooltip: 'Làm lại',
                onPressed: _controller.canRedo ? _controller.redo : null,
              ),
              IconButton(
                icon: const Icon(Icons.fit_screen),
                tooltip: 'Thu gọn toàn bản vẽ',
                onPressed: () => _controller.zoomToFit(_getCanvasSize()),
              ),
              PopupMenuButton<String>(
                tooltip: 'Xuất file & Tùy chọn',
                onSelected: (value) async {
                  switch (value) {
                    case 'dxf':
                      await _exportDxf();
                      break;
                    case 'pdf':
                      await _exportPdf();
                      break;
                    case 'sample':
                      _controller.loadSampleKitchenSurvey();
                      WidgetsBinding.instance.addPostFrameCallback((_) {
                        _controller.zoomToFit(_getCanvasSize());
                      });
                      break;
                    case 'clear':
                      _controller.clearAll();
                      break;
                  }
                },
                itemBuilder: (ctx) => const [
                  PopupMenuItem(
                    value: 'dxf',
                    child: ListTile(
                      leading: Icon(Icons.architecture),
                      title: Text('Xuất file DXF (AutoCAD)'),
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                  PopupMenuItem(
                    value: 'pdf',
                    child: ListTile(
                      leading: Icon(Icons.picture_as_pdf),
                      title: Text('Xuất file PDF kỹ thuật'),
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                  PopupMenuDivider(),
                  PopupMenuItem(
                    value: 'sample',
                    child: ListTile(
                      leading: Icon(Icons.science_outlined),
                      title: Text('Tải mẫu đo bếp chữ L'),
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                  PopupMenuItem(
                    value: 'clear',
                    child: ListTile(
                      leading: Icon(Icons.delete_sweep, color: Colors.redAccent),
                      title: Text('Xóa toàn bộ bản vẽ'),
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                ],
              ),
            ],
          ),
          body: Stack(
            children: [
              Positioned.fill(
                key: _canvasKey,
                child: CadCanvas(
                  controller: _controller,
                  onLineDraftFinished: _handleLineDraftFinished,
                  onLineTappedForEdit: _handleLineTappedForEdit,
                ),
              ),
              if (_isExporting)
                Container(
                  color: Colors.black54,
                  child: const Center(child: CircularProgressIndicator()),
                ),
              // Thanh hướng dẫn nhanh ở góc trên
              Positioned(
                top: 10,
                left: 12,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0F172A).withValues(alpha: 0.85),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: const Color(0xFF334155)),
                  ),
                  child: Text(
                    _controller.toolMode == ToolMode.drawLine
                        ? 'Kéo 1 ngón để vẽ • 2 ngón để Zoom/Di chuyển'
                        : _controller.toolMode == ToolMode.selectEdit
                            ? 'Chạm vào đoạn thẳng để sửa số đo (mm)'
                            : 'Kéo hoặc chụm 2 ngón để xem bản vẽ',
                    style: const TextStyle(
                      fontSize: 12,
                      color: Color(0xFFCBD5E1),
                    ),
                  ),
                ),
              ),
            ],
          ),
          bottomNavigationBar: SafeArea(
            child: Container(
              color: const Color(0xFF0F172A),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    SegmentedButton<ToolMode>(
                      showSelectedIcon: false,
                      segments: const [
                        ButtonSegment(
                          value: ToolMode.drawLine,
                          icon: Icon(Icons.edit, size: 18),
                          label: Text('Vẽ'),
                        ),
                        ButtonSegment(
                          value: ToolMode.selectEdit,
                          icon: Icon(Icons.tune, size: 18),
                          label: Text('Sửa mm'),
                        ),
                        ButtonSegment(
                          value: ToolMode.panZoom,
                          icon: Icon(Icons.pan_tool_alt, size: 18),
                          label: Text('Xem'),
                        ),
                      ],
                      selected: {_controller.toolMode},
                      onSelectionChanged: (s) =>
                          _controller.setToolMode(s.first),
                    ),
                    const SizedBox(width: 10),
                    FilterChip(
                      label: const Text('Vuông góc (90°)'),
                      selected: _controller.orthoEnabled,
                      onSelected: (_) => _controller.toggleOrtho(),
                    ),
                    const SizedBox(width: 8),
                    FilterChip(
                      label: const Text('Bắt điểm'),
                      selected: _controller.snapEnabled,
                      onSelected: (_) => _controller.toggleSnap(),
                    ),
                    const SizedBox(width: 8),
                    PopupMenuButton<CadLayer>(
                      onSelected: _controller.setActiveLayer,
                      itemBuilder: (ctx) => CadLayer.values
                          .map(
                            (l) => PopupMenuItem(
                              value: l,
                              child: Row(
                                children: [
                                  Container(
                                    width: 10,
                                    height: 10,
                                    decoration: BoxDecoration(
                                      color: l.color,
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Text(l.label),
                                ],
                              ),
                            ),
                          )
                          .toList(),
                      child: Chip(
                        avatar: CircleAvatar(
                          backgroundColor: _controller.activeLayer.color,
                          radius: 6,
                        ),
                        label: Text(_controller.activeLayer.label),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
