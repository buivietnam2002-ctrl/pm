import 'dart:math' as math;
import '../models/cad_models.dart';

/// Xuất bản vẽ 2D sang chuẩn AutoCAD DXF (AC1015 / R2000 ASCII) với đơn vị Millimeters.
class DxfExporter {
  static String generateDxf({
    required List<CadLine> lines,
    String projectName = 'Khao sat cong trinh',
  }) {
    final sb = StringBuffer();

    // Tính bounding box (lật trục Y vì màn hình Y hướng xuống, CAD Y hướng lên)
    double minX = 0, minY = 0, maxX = 1000, maxY = 1000;
    if (lines.isNotEmpty) {
      minX = double.infinity;
      minY = double.infinity;
      maxX = double.negativeInfinity;
      maxY = double.negativeInfinity;
      for (final line in lines) {
        final y1 = -line.start.y;
        final y2 = -line.end.y;
        minX = math.min(minX, math.min(line.start.x, line.end.x));
        maxX = math.max(maxX, math.max(line.start.x, line.end.x));
        minY = math.min(minY, math.min(y1, y2));
        maxY = math.max(maxY, math.max(y1, y2));
      }
    }

    // 1. HEADER SECTION
    _pair(sb, 0, 'SECTION');
    _pair(sb, 2, 'HEADER');
    _pair(sb, 9, r'$ACADVER');
    _pair(sb, 1, 'AC1015'); // AutoCAD 2000
    _pair(sb, 9, r'$INSUNITS');
    _pair(sb, 70, '4'); // 4 = Millimeters
    _pair(sb, 9, r'$MEASUREMENT');
    _pair(sb, 70, '1'); // 1 = Metric
    _pair(sb, 9, r'$EXTMIN');
    _pair(sb, 10, minX.toStringAsFixed(2));
    _pair(sb, 20, minY.toStringAsFixed(2));
    _pair(sb, 30, '0.0');
    _pair(sb, 9, r'$EXTMAX');
    _pair(sb, 10, maxX.toStringAsFixed(2));
    _pair(sb, 20, maxY.toStringAsFixed(2));
    _pair(sb, 30, '0.0');
    _pair(sb, 0, 'ENDSEC');

    // 2. TABLES SECTION (Layers)
    _pair(sb, 0, 'SECTION');
    _pair(sb, 2, 'TABLES');
    _pair(sb, 0, 'TABLE');
    _pair(sb, 2, 'LAYER');
    _pair(sb, 70, '${CadLayer.values.length + 1}');

    // Layer DIM mặc định cho kích thước
    _writeLayer(sb, name: 'DIM_TEXT', aciColor: 1); // Red
    for (final layer in CadLayer.values) {
      _writeLayer(sb, name: layer.dxfName, aciColor: layer.aciColor);
    }

    _pair(sb, 0, 'ENDTAB');
    _pair(sb, 0, 'ENDSEC');

    // 3. ENTITIES SECTION
    _pair(sb, 0, 'SECTION');
    _pair(sb, 2, 'ENTITIES');

    for (final line in lines) {
      final x1 = line.start.x;
      final y1 = -line.start.y;
      final x2 = line.end.x;
      final y2 = -line.end.y;

      // Vẽ LINE
      _pair(sb, 0, 'LINE');
      _pair(sb, 8, line.layer.dxfName);
      _pair(sb, 10, x1.toStringAsFixed(3));
      _pair(sb, 20, y1.toStringAsFixed(3));
      _pair(sb, 30, '0.0');
      _pair(sb, 11, x2.toStringAsFixed(3));
      _pair(sb, 21, y2.toStringAsFixed(3));
      _pair(sb, 31, '0.0');

      // Ghi chú kích thước mm dạng TEXT tại trung điểm
      final midX = (x1 + x2) / 2.0;
      final midY = (y1 + y2) / 2.0;
      var angleDeg = math.atan2(y2 - y1, x2 - x1) * 180.0 / math.pi;
      if (angleDeg > 90 || angleDeg < -90) {
        angleDeg += 180.0;
      }
      final dimLabel = line.note != null && line.note!.trim().isNotEmpty
          ? '${line.lengthMm.round()} mm (${line.note!.trim()})'
          : '${line.lengthMm.round()}';

      _pair(sb, 0, 'TEXT');
      _pair(sb, 8, 'DIM_TEXT');
      _pair(sb, 10, midX.toStringAsFixed(3));
      _pair(sb, 20, (midY + 60.0).toStringAsFixed(3));
      _pair(sb, 30, '0.0');
      _pair(sb, 40, '90.0'); // Chiều cao chữ 90mm phù hợp tỷ lệ công trình
      _pair(sb, 1, dimLabel);
      _pair(sb, 50, angleDeg.toStringAsFixed(2));
    }

    _pair(sb, 0, 'ENDSEC');
    _pair(sb, 0, 'EOF');

    return sb.toString();
  }

  static void _writeLayer(
    StringBuffer sb, {
    required String name,
    required int aciColor,
  }) {
    _pair(sb, 0, 'LAYER');
    _pair(sb, 2, name);
    _pair(sb, 70, '0');
    _pair(sb, 62, '$aciColor');
    _pair(sb, 6, 'CONTINUOUS');
  }

  static void _pair(StringBuffer sb, int groupCode, String value) {
    sb.writeln(groupCode.toString().padLeft(3));
    sb.writeln(value);
  }
}
