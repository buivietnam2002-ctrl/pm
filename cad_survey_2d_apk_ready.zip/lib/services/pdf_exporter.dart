import 'dart:math' as math;
import 'dart:typed_data';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../models/cad_models.dart';

/// Xuất bản vẽ khảo sát 2D sang file PDF vector chuẩn kỹ thuật (A4 Landscape).
class PdfExporter {
  static Future<Uint8List> generatePdf({
    required List<CadLine> lines,
    required String projectName,
    required String surveyorName,
  }) async {
    final doc = pw.Document(
      title: projectName,
      author: surveyorName,
    );

    final dateStr = DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now());

    doc.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4.landscape,
        margin: const pw.EdgeInsets.all(24),
        build: (context) {
          return pw.Container(
            decoration: pw.BoxDecoration(
              border: pw.Border.all(color: PdfColors.grey800, width: 1.5),
            ),
            padding: const pw.EdgeInsets.all(12),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.stretch,
              children: [
                // Khung bản vẽ vector chính
                pw.Expanded(
                  child: pw.Container(
                    decoration: pw.BoxDecoration(
                      border: pw.Border.all(color: PdfColors.grey400, width: 0.8),
                      color: PdfColors.white,
                    ),
                    child: lines.isEmpty
                        ? pw.Center(
                            child: pw.Text(
                              'Chua co du lieu ban ve',
                              style: const pw.TextStyle(
                                fontSize: 14,
                                color: PdfColors.grey600,
                              ),
                            ),
                          )
                        : pw.LayoutBuilder(
                            builder: (context, constraints) {
                              final w = constraints?.maxWidth ?? 700;
                              final h = constraints?.maxHeight ?? 440;
                              return pw.CustomPaint(
                                size: PdfPoint(w, h),
                                painter: (canvas, size) {
                                  _paintVectorDrawing(canvas, size, lines);
                                },
                              );
                            },
                          ),
                  ),
                ),
                pw.SizedBox(height: 8),
                // Khung tên kỹ thuật (Title Block)
                _buildTitleBlock(
                  projectName: projectName,
                  surveyorName: surveyorName,
                  dateStr: dateStr,
                  lineCount: lines.length,
                  scaleLabel: _computeScaleLabel(lines),
                ),
              ],
            ),
          );
        },
      ),
    );

    return doc.save();
  }

  static String _computeScaleLabel(List<CadLine> lines) {
    if (lines.isEmpty) return 'Auto';
    double minX = double.infinity, minY = double.infinity;
    double maxX = double.negativeInfinity, maxY = double.negativeInfinity;
    for (final l in lines) {
      minX = math.min(minX, math.min(l.start.x, l.end.x));
      maxX = math.max(maxX, math.max(l.start.x, l.end.x));
      minY = math.min(minY, math.min(l.start.y, l.end.y));
      maxY = math.max(maxY, math.max(l.start.y, l.end.y));
    }
    final spanMm = math.max(maxX - minX, maxY - minY);
    if (spanMm <= 0) return '1:1';
    final ratio = (spanMm / 200.0).ceil();
    return '1:$ratio (mm)';
  }

  static void _paintVectorDrawing(
    PdfGraphics canvas,
    PdfPoint size,
    List<CadLine> lines,
  ) {
    double minX = double.infinity, minY = double.infinity;
    double maxX = double.negativeInfinity, maxY = double.negativeInfinity;
    for (final l in lines) {
      minX = math.min(minX, math.min(l.start.x, l.end.x));
      maxX = math.max(maxX, math.max(l.start.x, l.end.x));
      minY = math.min(minY, math.min(l.start.y, l.end.y));
      maxY = math.max(maxY, math.max(l.start.y, l.end.y));
    }

    final widthMm = math.max(maxX - minX, 100.0);
    final heightMm = math.max(maxY - minY, 100.0);
    const padding = 48.0;

    final scaleX = (size.x - padding * 2) / widthMm;
    final scaleY = (size.y - padding * 2) / heightMm;
    final scale = math.min(scaleX, scaleY);

    final offsetX =
        size.x / 2.0 - ((minX + maxX) / 2.0) * scale;
    // Lưu ý: trong PDF gốc (0,0) ở góc dưới trái, nên trục Y đảo ngược so với màn hình
    final offsetY =
        size.y / 2.0 + ((minY + maxY) / 2.0) * scale;

    PdfPoint toPdf(CadPoint p) {
      return PdfPoint(
        p.x * scale + offsetX,
        offsetY - p.y * scale,
      );
    }

    final font = canvas.defaultFont ?? PdfFont.helvetica(canvas.document);

    for (final line in lines) {
      final p1 = toPdf(line.start);
      final p2 = toPdf(line.end);

      final color = _layerPdfColor(line.layer);
      canvas
        ..setStrokeColor(color)
        ..setLineWidth(line.layer == CadLayer.walls ? 2.0 : 1.3)
        ..moveTo(p1.x, p1.y)
        ..lineTo(p2.x, p2.y)
        ..strokePath();

      // Vẽ dấu chấm tại 2 đầu mút
      canvas
        ..setFillColor(color)
        ..drawEllipse(p1.x, p1.y, 2.0, 2.0)
        ..fillPath()
        ..drawEllipse(p2.x, p2.y, 2.0, 2.0)
        ..fillPath();

      // Vẽ nhãn kích thước mm tại trung điểm
      final midX = (p1.x + p2.x) / 2.0;
      final midY = (p1.y + p2.y) / 2.0;
      final label = '${line.lengthMm.round()}';

      canvas
        ..setFillColor(PdfColors.red800)
        ..drawString(
          font,
          9.0,
          label,
          midX + 4,
          midY + 4,
        );
    }
  }

  static PdfColor _layerPdfColor(CadLayer layer) {
    switch (layer) {
      case CadLayer.walls:
        return PdfColors.black;
      case CadLayer.furniture:
        return PdfColors.blue700;
      case CadLayer.openings:
        return PdfColors.orange700;
      case CadLayer.annotations:
        return PdfColors.green700;
    }
  }

  static pw.Widget _buildTitleBlock({
    required String projectName,
    required String surveyorName,
    required String dateStr,
    required int lineCount,
    required String scaleLabel,
  }) {
    return pw.Container(
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey800, width: 1),
        color: PdfColors.grey100,
      ),
      padding: const pw.EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text(
                'CONG TRINH: $projectName',
                style: pw.TextStyle(
                  fontSize: 11,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
              pw.SizedBox(height: 2),
              pw.Text(
                'Nguoi do: $surveyorName  |  Ngay: $dateStr',
                style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700),
              ),
            ],
          ),
          pw.Row(
            children: [
              _infoCell('DON VI', 'mm'),
              pw.SizedBox(width: 16),
              _infoCell('TY LE', scaleLabel),
              pw.SizedBox(width: 16),
              _infoCell('SO DOAN', '$lineCount'),
            ],
          ),
        ],
      ),
    );
  }

  static pw.Widget _infoCell(String label, String value) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.end,
      children: [
        pw.Text(label,
            style: const pw.TextStyle(fontSize: 7, color: PdfColors.grey600)),
        pw.Text(
          value,
          style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold),
        ),
      ],
    );
  }
}
