import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../controllers/cad_controller.dart';
import '../models/cad_models.dart';

class CadCanvas extends StatefulWidget {
  final CadController controller;
  final Future<void> Function(
    CadPoint start,
    double draftLengthMm,
    double draftAngleDeg,
  ) onLineDraftFinished;
  final Future<void> Function(CadLine line) onLineTappedForEdit;

  const CadCanvas({
    super.key,
    required this.controller,
    required this.onLineDraftFinished,
    required this.onLineTappedForEdit,
  });

  @override
  State<CadCanvas> createState() => _CadCanvasState();
}

class _CadCanvasState extends State<CadCanvas> {
  double _baseScale = 1.0;
  Offset _lastFocalPoint = Offset.zero;
  bool _isMultiTouchPanZoom = false;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.controller,
      builder: (context, _) {
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapUp: (details) async {
            if (widget.controller.toolMode == ToolMode.selectEdit) {
              final hit = widget.controller.selectAt(details.localPosition);
              if (hit != null) {
                await widget.onLineTappedForEdit(hit);
              }
            } else if (widget.controller.toolMode == ToolMode.drawLine) {
              // Nếu chạm vào đoạn thẳng khi đang ở chế độ chọn nhanh
              final hit = widget.controller.selectAt(details.localPosition);
              if (hit != null) {
                await widget.onLineTappedForEdit(hit);
              }
            }
          },
          onScaleStart: (details) {
            _lastFocalPoint = details.localFocalPoint;
            _baseScale = 1.0;

            if (details.pointerCount >= 2 ||
                widget.controller.toolMode == ToolMode.panZoom) {
              _isMultiTouchPanZoom = true;
              widget.controller.cancelDrawing();
            } else {
              _isMultiTouchPanZoom = false;
              if (widget.controller.toolMode == ToolMode.drawLine) {
                widget.controller.startDrawingAt(details.localFocalPoint);
              }
            }
          },
          onScaleUpdate: (details) {
            if (details.pointerCount >= 2 || _isMultiTouchPanZoom) {
              if (!_isMultiTouchPanZoom) {
                _isMultiTouchPanZoom = true;
                widget.controller.cancelDrawing();
              }
              final delta = details.localFocalPoint - _lastFocalPoint;
              widget.controller.panBy(delta);
              if ((details.scale - _baseScale).abs() > 0.005) {
                final zoomFactor = details.scale / _baseScale;
                widget.controller.zoomAt(zoomFactor, details.localFocalPoint);
                _baseScale = details.scale;
              }
              _lastFocalPoint = details.localFocalPoint;
            } else if (widget.controller.toolMode == ToolMode.drawLine) {
              widget.controller.updateDrawingTo(details.localFocalPoint);
            }
          },
          onScaleEnd: (details) async {
            if (_isMultiTouchPanZoom) {
              _isMultiTouchPanZoom = false;
              return;
            }
            if (widget.controller.toolMode == ToolMode.drawLine) {
              final draft = widget.controller.finishDrawingDraft();
              if (draft != null) {
                await widget.onLineDraftFinished(
                  draft.start,
                  draft.lengthMm,
                  draft.angleDeg,
                );
              }
            }
          },
          child: CustomPaint(
            painter: CadCanvasPainter(controller: widget.controller),
            size: Size.infinite,
          ),
        );
      },
    );
  }
}

class CadCanvasPainter extends CustomPainter {
  final CadController controller;

  CadCanvasPainter({required this.controller});

  @override
  void paint(Canvas canvas, Size size) {
    _drawGrid(canvas, size);
    _drawOrigin(canvas);

    // Vẽ tất cả các đoạn thẳng đã lưu
    for (final line in controller.lines) {
      final isSelected = line.id == controller.selectedLineId;
      _drawLineWithDimension(
        canvas,
        line.start,
        line.end,
        color: line.layer.color,
        strokeWidth: line.layer.strokeWidth,
        isSelected: isSelected,
        note: line.note,
      );
    }

    // Vẽ đoạn thẳng xem trước khi đang kéo tay
    if (controller.activeStartPoint != null &&
        controller.activePreviewEndPoint != null) {
      _drawLineWithDimension(
        canvas,
        controller.activeStartPoint!,
        controller.activePreviewEndPoint!,
        color: const Color(0xFF38BDF8),
        strokeWidth: 2.5,
        isPreview: true,
      );
    }

    // Vẽ điểm bắt (Snap Indicator)
    final snap = controller.currentSnap;
    if (snap != null && snap.type != SnapType.none) {
      final sp = controller.worldToScreen(snap.point);
      final snapPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.0
        ..color = snap.type == SnapType.endpoint
            ? const Color(0xFF4ADE80)
            : snap.type == SnapType.midpoint
                ? const Color(0xFF22D3EE)
                : const Color(0xFF94A3B8);

      if (snap.type == SnapType.endpoint) {
        canvas.drawRect(
          Rect.fromCenter(center: sp, width: 12, height: 12),
          snapPaint,
        );
      } else if (snap.type == SnapType.midpoint) {
        final path = Path()
          ..moveTo(sp.dx, sp.dy - 7)
          ..lineTo(sp.dx - 6, sp.dy + 5)
          ..lineTo(sp.dx + 6, sp.dy + 5)
          ..close();
        canvas.drawPath(path, snapPaint);
      }
    }
  }

  void _drawGrid(Canvas canvas, Size size) {
    // Chọn bước lưới thích ứng để không bị rối mắt khi zoom xa/gần
    double stepMm = controller.gridSizeMm;
    while (stepMm * controller.scale < 18.0) {
      stepMm *= 5.0;
    }
    while (stepMm * controller.scale > 120.0 && stepMm > 10.0) {
      stepMm /= 2.0;
    }

    final topLeftWorld = controller.screenToWorld(Offset.zero);
    final bottomRightWorld =
        controller.screenToWorld(Offset(size.width, size.height));

    final startX = (topLeftWorld.x / stepMm).floor() * stepMm;
    final endX = (bottomRightWorld.x / stepMm).ceil() * stepMm;
    final startY = (topLeftWorld.y / stepMm).floor() * stepMm;
    final endY = (bottomRightWorld.y / stepMm).ceil() * stepMm;

    final minorPaint = Paint()
      ..color = const Color(0xFF1E293B)
      ..strokeWidth = 1.0;

    final majorPaint = Paint()
      ..color = const Color(0xFF334155)
      ..strokeWidth = 1.2;

    for (double x = startX; x <= endX; x += stepMm) {
      final sx = controller.worldToScreen(CadPoint(x, 0)).dx;
      final isMajor = (x % (stepMm * 5)).abs() < 1e-3;
      canvas.drawLine(
        Offset(sx, 0),
        Offset(sx, size.height),
        isMajor ? majorPaint : minorPaint,
      );
    }

    for (double y = startY; y <= endY; y += stepMm) {
      final sy = controller.worldToScreen(CadPoint(0, y)).dy;
      final isMajor = (y % (stepMm * 5)).abs() < 1e-3;
      canvas.drawLine(
        Offset(0, sy),
        Offset(size.width, sy),
        isMajor ? majorPaint : minorPaint,
      );
    }
  }

  void _drawOrigin(Canvas canvas) {
    final origin = controller.worldToScreen(const CadPoint(0, 0));
    final xAxisPaint = Paint()
      ..color = const Color(0xFFEF4444).withValues(alpha: 0.7)
      ..strokeWidth = 1.5;
    final yAxisPaint = Paint()
      ..color = const Color(0xFF22C55E).withValues(alpha: 0.7)
      ..strokeWidth = 1.5;

    canvas.drawLine(origin, origin + const Offset(28, 0), xAxisPaint);
    canvas.drawLine(origin, origin + const Offset(0, 28), yAxisPaint);
    canvas.drawCircle(
      origin,
      3.5,
      Paint()..color = const Color(0xFFF8FAFC),
    );
  }

  void _drawLineWithDimension(
    Canvas canvas,
    CadPoint startWorld,
    CadPoint endWorld, {
    required Color color,
    required double strokeWidth,
    bool isSelected = false,
    bool isPreview = false,
    String? note,
  }) {
    final p1 = controller.worldToScreen(startWorld);
    final p2 = controller.worldToScreen(endWorld);

    if (isSelected) {
      final glowPaint = Paint()
        ..color = const Color(0xFF38BDF8).withValues(alpha: 0.35)
        ..strokeWidth = strokeWidth + 8
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(p1, p2, glowPaint);
    }

    final linePaint = Paint()
      ..color = isSelected ? const Color(0xFF38BDF8) : color
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(p1, p2, linePaint);

    // Điểm đầu & điểm cuối
    final endpointPaint = Paint()
      ..color = isPreview ? const Color(0xFF38BDF8) : const Color(0xFFF8FAFC);
    canvas.drawCircle(p1, isSelected ? 4.5 : 3.0, endpointPaint);
    canvas.drawCircle(p2, isSelected ? 4.5 : 3.0, endpointPaint);

    // Nhãn kích thước mm
    final lenMm = startWorld.distanceTo(endWorld);
    if (lenMm < 1) return;

    final mid = Offset((p1.dx + p2.dx) / 2, (p1.dy + p2.dy) / 2);
    final dx = p2.dx - p1.dx;
    final dy = p2.dy - p1.dy;
    final pixelLen = math.sqrt(dx * dx + dy * dy);
    if (pixelLen < 24 && !isPreview) return;

    // Vector pháp tuyến để đẩy chữ ra khỏi đường thẳng một chút
    final nx = pixelLen > 0 ? -dy / pixelLen : 0.0;
    final ny = pixelLen > 0 ? dx / pixelLen : -1.0;
    final labelCenter = mid + Offset(nx * 16, ny * 16);

    final text = note != null && note.trim().isNotEmpty
        ? '${lenMm.round()} mm • ${note.trim()}'
        : '${lenMm.round()} mm';

    final tp = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          color: isPreview
              ? const Color(0xFF38BDF8)
              : isSelected
                  ? const Color(0xFF7DD3FC)
                  : const Color(0xFFE2E8F0),
          fontSize: isPreview ? 13 : 11.5,
          fontWeight: isPreview || isSelected ? FontWeight.bold : FontWeight.w500,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();

    final badgeRect = Rect.fromCenter(
      center: labelCenter,
      width: tp.width + 10,
      height: tp.height + 4,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(badgeRect, const Radius.circular(4)),
      Paint()..color = const Color(0xFF0F172A).withValues(alpha: 0.88),
    );
    tp.paint(
      canvas,
      Offset(labelCenter.dx - tp.width / 2, labelCenter.dy - tp.height / 2),
    );
  }

  @override
  bool shouldRepaint(covariant CadCanvasPainter oldDelegate) => true;
}
