import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/cad_models.dart';

class DimensionInputResult {
  final double lengthMm;
  final double angleDeg;
  final CadLayer layer;
  final String? note;
  final bool anchorStart;
  final bool deleted;

  const DimensionInputResult({
    required this.lengthMm,
    required this.angleDeg,
    required this.layer,
    this.note,
    this.anchorStart = true,
    this.deleted = false,
  });
}

/// Hộp thoại nhập số đo công trình (mm) & góc chính xác, tối ưu cho cảm ứng tại hiện trường.
Future<DimensionInputResult?> showDimensionInputDialog({
  required BuildContext context,
  required double initialLengthMm,
  required double initialAngleDeg,
  required CadLayer initialLayer,
  String? initialNote,
  bool isEditing = false,
}) {
  return showModalBottomSheet<DimensionInputResult>(
    context: context,
    isScrollControlled: true,
    backgroundColor: const Color(0xFF0F172A),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
    ),
    builder: (ctx) => _DimensionInputSheet(
      initialLengthMm: initialLengthMm,
      initialAngleDeg: initialAngleDeg,
      initialLayer: initialLayer,
      initialNote: initialNote,
      isEditing: isEditing,
    ),
  );
}

class _DimensionInputSheet extends StatefulWidget {
  final double initialLengthMm;
  final double initialAngleDeg;
  final CadLayer initialLayer;
  final String? initialNote;
  final bool isEditing;

  const _DimensionInputSheet({
    required this.initialLengthMm,
    required this.initialAngleDeg,
    required this.initialLayer,
    this.initialNote,
    required this.isEditing,
  });

  @override
  State<_DimensionInputSheet> createState() => _DimensionInputSheetState();
}

class _DimensionInputSheetState extends State<_DimensionInputSheet> {
  late final TextEditingController _lengthCtrl;
  late final TextEditingController _angleCtrl;
  late final TextEditingController _noteCtrl;
  late CadLayer _selectedLayer;
  bool _anchorStart = true;

  @override
  void initState() {
    super.initState();
    _lengthCtrl = TextEditingController(
      text: widget.initialLengthMm.round().toString(),
    )..selection = TextSelection(
        baseOffset: 0,
        extentOffset: widget.initialLengthMm.round().toString().length,
      );
    _angleCtrl = TextEditingController(
      text: widget.initialAngleDeg.toStringAsFixed(0),
    );
    _noteCtrl = TextEditingController(text: widget.initialNote ?? '');
    _selectedLayer = widget.initialLayer;
  }

  @override
  void dispose() {
    _lengthCtrl.dispose();
    _angleCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  void _submit() {
    final len = double.tryParse(_lengthCtrl.text.replaceAll(',', '.').trim());
    final ang = double.tryParse(_angleCtrl.text.replaceAll(',', '.').trim()) ??
        widget.initialAngleDeg;
    if (len == null || len <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Vui lòng nhập chiều dài hợp lệ (> 0 mm)')),
      );
      return;
    }
    Navigator.of(context).pop(
      DimensionInputResult(
        lengthMm: len,
        angleDeg: ang,
        layer: _selectedLayer,
        note: _noteCtrl.text.trim().isEmpty ? null : _noteCtrl.text.trim(),
        anchorStart: _anchorStart,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;

    return Padding(
      padding: EdgeInsets.fromLTRB(20, 16, 20, 16 + bottomInset),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  widget.isEditing
                      ? 'Chỉnh sửa kích thước (mm)'
                      : 'Nhập số đo thực tế (mm)',
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                if (widget.isEditing)
                  IconButton(
                    icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                    tooltip: 'Xóa đoạn thẳng',
                    onPressed: () {
                      Navigator.of(context).pop(
                        DimensionInputResult(
                          lengthMm: widget.initialLengthMm,
                          angleDeg: widget.initialAngleDeg,
                          layer: _selectedLayer,
                          deleted: true,
                        ),
                      );
                    },
                  ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  flex: 2,
                  child: TextField(
                    controller: _lengthCtrl,
                    autofocus: true,
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]')),
                    ],
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF38BDF8),
                    ),
                    decoration: const InputDecoration(
                      labelText: 'Chiều dài (mm)',
                      suffixText: 'mm',
                      border: OutlineInputBorder(),
                    ),
                    onSubmitted: (_) => _submit(),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: _angleCtrl,
                    keyboardType: const TextInputType.numberWithOptions(
                      signed: true,
                      decimal: true,
                    ),
                    style: const TextStyle(fontSize: 18),
                    decoration: const InputDecoration(
                      labelText: 'Góc (°)',
                      suffixText: '°',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            // Nút chọn nhanh góc vuông (0°, 90°, 180°, -90°)
            Wrap(
              spacing: 8,
              children: [
                for (final deg in [0, 90, 180, -90])
                  ActionChip(
                    label: Text('$deg°'),
                    onPressed: () {
                      setState(() {
                        _angleCtrl.text = '$deg';
                      });
                    },
                  ),
              ],
            ),
            const SizedBox(height: 12),
            // Chọn Layer
            DropdownButtonFormField<CadLayer>(
              value: _selectedLayer,
              decoration: const InputDecoration(
                labelText: 'Lớp (Layer)',
                border: OutlineInputBorder(),
              ),
              items: CadLayer.values
                  .map(
                    (layer) => DropdownMenuItem(
                      value: layer,
                      child: Row(
                        children: [
                          Container(
                            width: 12,
                            height: 12,
                            decoration: BoxDecoration(
                              color: layer.color,
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text('${layer.label} (${layer.dxfName})'),
                        ],
                      ),
                    ),
                  )
                  .toList(),
              onChanged: (val) {
                if (val != null) setState(() => _selectedLayer = val);
              },
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _noteCtrl,
              decoration: const InputDecoration(
                labelText: 'Ghi chú (VD: Tường bếp, Cửa sổ...)',
                border: OutlineInputBorder(),
              ),
            ),
            if (widget.isEditing) ...[
              const SizedBox(height: 8),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Cố định điểm đầu khi đổi chiều dài'),
                value: _anchorStart,
                onChanged: (v) => setState(() => _anchorStart = v),
              ),
            ],
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text('Hủy'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: FilledButton.icon(
                    onPressed: _submit,
                    icon: const Icon(Icons.check),
                    label: Text(widget.isEditing ? 'Cập nhật' : 'Áp dụng số đo'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
