import 'package:flutter_test/flutter_test.dart';
import 'package:cad_survey_2d/controllers/cad_controller.dart';
import 'package:cad_survey_2d/models/cad_models.dart';
import 'package:cad_survey_2d/services/dxf_exporter.dart';

void main() {
  group('CAD Geometry & Exact Millimeter Tests', () {
    test('CadLine calculates exact length in mm and updates length cleanly', () {
      const line = CadLine(
        id: 'l1',
        start: CadPoint(0, 0),
        end: CadPoint(1250, 0),
      );
      expect(line.lengthMm, closeTo(1250.0, 1e-6));

      final resized = line.withExactLength(3600.0, anchorStart: true);
      expect(resized.start, const CadPoint(0, 0));
      expect(resized.end.x, closeTo(3600.0, 1e-6));
      expect(resized.lengthMm, closeTo(3600.0, 1e-6));
    });

    test('CadController ortho lock snaps to horizontal or vertical axis', () {
      final controller = CadController()
        ..orthoEnabled = true
        ..snapEnabled = false;

      const anchor = CadPoint(1000, 1000);
      final res = controller.findSnap(
        const CadPoint(2500, 1180),
        orthoAnchor: anchor,
      );
      expect(res.point.x, closeTo(2500.0, 1e-6));
      expect(res.point.y, closeTo(1000.0, 1e-6));
    });

    test('CadController supports Undo and Redo', () {
      final controller = CadController();
      controller.commitLineExact(
        start: const CadPoint(0, 0),
        lengthMm: 2400,
        angleDeg: 0,
      );
      expect(controller.lines.length, 1);

      controller.undo();
      expect(controller.lines.length, 0);

      controller.redo();
      expect(controller.lines.length, 1);
      expect(controller.lines.first.lengthMm, closeTo(2400.0, 1e-6));
    });
  });

  group('DXF Exporter Tests', () {
    test('Generates valid AC1015 DXF with Millimeter units and LINE entities', () {
      const lines = [
        CadLine(
          id: 'w1',
          start: CadPoint(0, 0),
          end: CadPoint(3600, 0),
          layer: CadLayer.walls,
          note: 'Tuong bep',
        ),
      ];

      final dxf = DxfExporter.generateDxf(lines: lines);
      expect(dxf.contains('AC1015'), isTrue);
      expect(dxf.contains(r'$INSUNITS'), isTrue);
      expect(dxf.contains('LINE'), isTrue);
      expect(dxf.contains('3600.000'), isTrue);
      expect(dxf.contains('WALL'), isTrue);
      expect(dxf.trim().endsWith('EOF'), isTrue);
    });
  });
}
